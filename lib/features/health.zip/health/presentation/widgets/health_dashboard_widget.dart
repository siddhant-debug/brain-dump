import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../../../../core/theme/app_theme.dart';
import '../../controllers/health_sync_controller.dart';
import '../../models/health_snapshot.dart';

class HealthDashboardWidget extends ConsumerWidget {
  const HealthDashboardWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final healthState = ref.watch(healthSyncControllerProvider);

    return Container(
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
        border: Border.all(color: Colors.white.withValues(alpha: 0.05)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            margin: const EdgeInsets.only(top: 12, bottom: 24),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.surfaceHigh,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Row(
                    children: [
                      Icon(
                        Icons.health_and_safety_rounded,
                        color: AppColors.accent,
                        size: 24,
                      ),
                      const SizedBox(width: 12),
                      Text(
                        'Health Vibe',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          letterSpacing: -0.5,
                        ),
                      ),
                    ],
                  ),
                ),
                if (healthState.isAuthorized ||
                    healthState.isPartiallyAuthorized)
                  Expanded(
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: _buildStatusChip(healthState),
                    ),
                  )
                else
                  _buildConnectButton(ref),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Content
          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 40),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (healthState.error != null)
                    _buildErrorBanner(healthState.error!),

                  if (healthState.isFetching)
                    const Padding(
                      padding: EdgeInsets.all(32.0),
                      child: Center(
                        child: CircularProgressIndicator(strokeWidth: 2.0),
                      ),
                    )
                  else if (healthState.isAuthorized ||
                      healthState.isPartiallyAuthorized)
                    _buildMetricsGrid(healthState.latestSnapshot),

                  const SizedBox(height: 24),

                  if (healthState.latestSnapshot != null)
                    _buildDebugPanel(healthState.latestSnapshot!),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectButton(WidgetRef ref) {
    return TextButton(
      style: TextButton.styleFrom(
        foregroundColor: AppColors.accent,
        backgroundColor: AppColors.accent.withValues(alpha: 0.1),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      onPressed: () {
        ref.read(healthSyncControllerProvider.notifier).requestPermission();
      },
      child: const Text(
        'Connect Apple Health',
        style: TextStyle(fontWeight: FontWeight.w600),
      ),
    );
  }

  Widget _buildStatusChip(HealthContextState state) {
    final isPartial = state.isPartiallyAuthorized;
    final color = isPartial ? Colors.orange : AppColors.success;
    final text = isPartial
        ? 'Partial Access'
        : 'Connected directly to Apple Health';

    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        if (state.isFetching) ...[
          SizedBox(
            width: 12,
            height: 12,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(width: 8),
        ],
        Flexible(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withValues(alpha: 0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    text,
                    style: TextStyle(
                      color: color,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.2,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 4),
        Consumer(
          builder: (context, ref, _) {
            return IconButton(
              icon: Icon(
                Icons.refresh_rounded,
                color: AppColors.textSecondary,
                size: 20,
              ),
              onPressed: state.isFetching
                  ? null
                  : () => ref
                        .read(healthSyncControllerProvider.notifier)
                        .refreshHealthContext(),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
              splashRadius: 20,
            );
          },
        ),
      ],
    );
  }

  Widget _buildErrorBanner(String error) {
    return Container(
      margin: const EdgeInsets.only(bottom: 24),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.error.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.error.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: AppColors.error, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              error,
              style: TextStyle(color: AppColors.error, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricsGrid(HealthSnapshot? snap) {
    if (snap == null) {
      return Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surfaceHigh,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Center(
          child: Text(
            'No health data synced yet.',
            style: TextStyle(color: Colors.white54),
          ),
        ),
      );
    }

    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      childAspectRatio: 1.5,
      children: [
        _MetricCard(
          icon: Icons.favorite,
          color: Colors.redAccent,
          title: 'Heart Rate',
          value: snap.heartRateCurrent?.toStringAsFixed(0) ?? '--',
          unit: 'bpm',
          subtitle: snap.heartRateAvg24h != null
              ? 'Avg 24h: ${snap.heartRateAvg24h!.toStringAsFixed(0)} bpm'
              : null,
          isDenied: !snap.authorizedTypes.contains('HeartRate'),
        ),

        _MetricCard(
          icon: Icons.nights_stay,
          color: Colors.indigoAccent,
          title: 'Sleep',
          value: snap.lastNightSleep?.totalHours.toStringAsFixed(1) ?? '--',
          unit: 'hrs',
          subtitle: snap.lastNightSleep != null
              ? 'Deep: ${snap.lastNightSleep!.deepHours.toStringAsFixed(1)}h'
              : null,
          isDenied: !snap.authorizedTypes.contains('SleepAnalysis'),
        ),
        _MetricCard(
          icon: Icons.directions_walk,
          color: Colors.orangeAccent,
          title: 'Steps Today',
          value: snap.stepsToday?.toString() ?? '--',
          unit: 'steps',
          isDenied: !snap.authorizedTypes.contains('StepCount'),
        ),
        _MetricCard(
          icon: Icons.local_fire_department,
          color: Colors.deepOrange,
          title: 'Active Energy',
          value: snap.activeEnergyToday?.toStringAsFixed(0) ?? '--',
          unit: 'kcal',
          isDenied: !snap.authorizedTypes.contains('ActiveEnergyBurned'),
        ),

        _MetricCard(
          icon: Icons.fitness_center,
          color: Colors.lightGreenAccent,
          title: 'Last Workout',
          value: snap.lastWorkout != null
              ? snap.lastWorkout!.durationMinutes.toStringAsFixed(0)
              : '--',
          unit: 'min',
          subtitle: snap.lastWorkout?.type,
          isDenied: !snap.authorizedTypes.contains('Workout'),
        ),
      ],
    );
  }

  Widget _buildDebugPanel(HealthSnapshot snap) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E1E),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.bug_report, size: 16, color: Colors.white54),
              const SizedBox(width: 8),
              const Text(
                'Raw Backend Context (RAG)',
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              Text(
                'Fetched ${timeago.format(snap.fetchedAt)}',
                style: const TextStyle(color: Colors.white38, fontSize: 10),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            snap.toJson().toString(),
            style: const TextStyle(
              color: Colors.greenAccent,
              fontFamily: 'Courier',
              fontSize: 10,
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String value;
  final String unit;
  final String? subtitle;
  final bool isDenied;

  const _MetricCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.value,
    required this.unit,
    this.subtitle,
    required this.isDenied,
  });

  @override
  Widget build(BuildContext context) {
    final displayColor = isDenied ? Colors.grey.withValues(alpha: 0.3) : color;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surfaceHigh,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: displayColor.withValues(alpha: 0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Icon(icon, color: displayColor, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    color: isDenied ? Colors.white38 : AppColors.textSecondary,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const Spacer(),
          if (isDenied)
            const Text(
              'Not Available',
              style: TextStyle(
                color: Colors.white24,
                fontSize: 13,
                fontStyle: FontStyle.italic,
              ),
            )
          else ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    color: isDenied ? Colors.white38 : AppColors.textPrimary,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 4),
                Text(
                  unit,
                  style: TextStyle(
                    color: isDenied ? Colors.white24 : AppColors.textSecondary,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 4),
              Text(
                subtitle!,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: isDenied ? Colors.white24 : AppColors.textSecondary,
                  fontSize: 10,
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }
}
