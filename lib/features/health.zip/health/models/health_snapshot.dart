class SleepSummary {
  final double totalHours;
  final double deepHours;
  final double remHours;
  final double awakeHours;

  SleepSummary({
    required this.totalHours,
    required this.deepHours,
    required this.remHours,
    required this.awakeHours,
  });

  factory SleepSummary.fromMap(Map<Object?, Object?> map) {
    return SleepSummary(
      totalHours: (map['total_hours'] as num?)?.toDouble() ?? 0.0,
      deepHours: (map['deep_hours'] as num?)?.toDouble() ?? 0.0,
      remHours: (map['rem_hours'] as num?)?.toDouble() ?? 0.0,
      awakeHours: (map['awake_hours'] as num?)?.toDouble() ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() => {
    'total_hours': totalHours,
    'deep_hours': deepHours,
    'rem_hours': remHours,
    'awake_hours': awakeHours,
  };
}

class WorkoutSummary {
  final String type;
  final double durationMinutes;
  final double? calories;

  WorkoutSummary({
    required this.type,
    required this.durationMinutes,
    this.calories,
  });

  factory WorkoutSummary.fromMap(Map<Object?, Object?> map) {
    return WorkoutSummary(
      type: map['type'] as String? ?? 'Unknown',
      durationMinutes: (map['duration_minutes'] as num?)?.toDouble() ?? 0.0,
      calories: (map['calories'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
    'type': type,
    'duration_minutes': durationMinutes,
    'calories': calories,
  };
}

class HealthSnapshot {
  final double? heartRateCurrent;
  final double? heartRateAvg24h;
  final SleepSummary? lastNightSleep;
  final int? stepsToday;
  final double? activeEnergyToday;
  final WorkoutSummary? lastWorkout;
  final Set<String> authorizedTypes; // which types were actually granted
  final DateTime fetchedAt;

  HealthSnapshot({
    this.heartRateCurrent,
    this.heartRateAvg24h,
    this.lastNightSleep,
    this.stepsToday,
    this.activeEnergyToday,
    this.lastWorkout,
    required this.authorizedTypes,
    required this.fetchedAt,
  });

  Map<String, dynamic> toJson() => {
    'heart_rate': {'current': heartRateCurrent, 'avg_24h': heartRateAvg24h},
    'sleep': lastNightSleep?.toJson(),
    'steps_today': stepsToday,
    'active_energy_kcal': activeEnergyToday,
    'last_workout': lastWorkout?.toJson(),
    'fetched_at': fetchedAt.toIso8601String(),
  };
}
