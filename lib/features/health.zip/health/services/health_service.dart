import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import '../models/health_snapshot.dart';
import 'health_service_interface.dart';

class HealthService implements HealthServiceInterface {
  static const _channel = MethodChannel('com.braindump.health');

  @override
  Future<bool> requestAuthorization() async {
    try {
      final authResult = await _channel.invokeMethod('requestAuthorization');
      return authResult == true;
    } on PlatformException catch (e) {
      debugPrint(
        '[HealthService] PlatformException requesting auth: ${e.message}',
      );
      throw Exception(e.message ?? 'Unknown HealthKit Error');
    } catch (e) {
      debugPrint('[HealthService] Error requesting authorization: $e');
      throw Exception(e.toString());
    }
  }

  @override
  Future<Map<String, String>> checkAuthorization() async {
    try {
      final statusMap = await _channel.invokeMethod('checkAuthorizationStatus');
      if (statusMap is Map) {
        return Map<String, String>.from(statusMap);
      }
      return {};
    } catch (e) {
      debugPrint('[HealthService] Error checking authorization: $e');
      return {};
    }
  }

  @override
  Future<Set<String>> getAuthorizedTypes() async {
    final statusMap = await checkAuthorization();
    final authorized = <String>{};
    for (var entry in statusMap.entries) {
      // If we got past the iOS prompt, we consider it "authorized" for our purposes
      // since Apple doesn't let us read the true read status.
      if (entry.value == 'authorized') {
        authorized.add(entry.key);
      }
    }
    return authorized;
  }

  @override
  Future<void> reinitAfterAuthorization() async {
    // Empty for HealthKit, as there are no JWT tokens to fetch unlike MusicKit.
    // The delay inside the Controller is what matters for HealthKit DB sync.
  }

  @override
  Future<String> getRawDebugState() async {
    try {
      final statuses = await checkAuthorization();
      return 'Auth Statuses: $statuses';
    } catch (e) {
      return 'Raw State Error: $e';
    }
  }

  @override
  Future<HealthSnapshot?> getLatestSnapshot() async {
    try {
      // Fetch all concurrently
      final responses = await Future.wait([
        _channel.invokeMethod('getHeartRate'),
        _channel.invokeMethod('getSleep'),
        _channel.invokeMethod('getSteps'),
        _channel.invokeMethod('getActiveEnergy'),
        _channel.invokeMethod('getWorkouts'),
      ]);

      // Parse results (each index corresponds to the method above)
      final heartRateData = responses[0] as Map<Object?, Object?>?;
      final sleepData = responses[1] as Map<Object?, Object?>?;
      final stepsData = responses[2] as int?;
      final energyData = responses[3] as double?;
      final workoutData = responses[4] as Map<Object?, Object?>?;

      // Only include types that exist or we are authorized to read (we assume authorized based on our interface)
      final authorizedTypes = await getAuthorizedTypes();

      return HealthSnapshot(
        heartRateCurrent: (heartRateData?['current'] as num?)?.toDouble(),
        heartRateAvg24h: (heartRateData?['avg_24h'] as num?)?.toDouble(),
        lastNightSleep: sleepData != null
            ? SleepSummary.fromMap(sleepData)
            : null,
        stepsToday: stepsData,
        activeEnergyToday: energyData,
        lastWorkout: workoutData != null
            ? WorkoutSummary.fromMap(workoutData)
            : null,
        authorizedTypes: authorizedTypes,
        fetchedAt: DateTime.now().toUtc(),
      );
    } catch (e) {
      debugPrint('[HealthService] Error getting latest snapshot: $e');
      return null;
    }
  }
}
