import Foundation
import HealthKit
import Flutter

class HealthKitService {
    static let shared = HealthKitService()
    let healthStore = HKHealthStore()
    
    // Define the types we want to read
    private lazy var readTypes: Set<HKObjectType> = {
        var types: Set<HKObjectType> = []
        if let hr = HKObjectType.quantityType(forIdentifier: .heartRate) { types.insert(hr) }
        // Adding dietaryWater entirely to force iOS to show the prompt again, as it's a new unknown requested type
        if let water = HKObjectType.quantityType(forIdentifier: .dietaryWater) { types.insert(water) }
        if let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) { types.insert(sleep) }
        if let steps = HKObjectType.quantityType(forIdentifier: .stepCount) { types.insert(steps) }
        if let energy = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) { types.insert(energy) }
        types.insert(HKObjectType.workoutType())
        return types
    }()
    
    init() {
        // HealthKit types are now initialized lazily when `readTypes` is first accessed.
        // No need to check HKHealthStore.isHealthDataAvailable() here for type initialization.
    }
    
    func setupChannel(messenger: FlutterBinaryMessenger) {
        let channel = FlutterMethodChannel(name: "com.braindump.health", binaryMessenger: messenger)
        channel.setMethodCallHandler { [weak self] (call, result) in
            guard let self = self else { return }
            
            if !HKHealthStore.isHealthDataAvailable() {
                result(FlutterError(code: "UNAVAILABLE", message: "HealthKit is not available on this device", details: nil))
                return
            }
            
            switch call.method {
            case "requestAuthorization":
                self.requestAuthorization(result: result)
            case "checkAuthorizationStatus":
                self.checkAuthorizationStatus(result: result)
            case "getHeartRate":
                self.getHeartRate(result: result)
            case "getHRV":
                self.getHRV(result: result)
            case "getSleep":
                self.getSleep(result: result)
            case "getSteps":
                self.getSteps(result: result)
            case "getActiveEnergy":
                self.getActiveEnergy(result: result)
            case "getWorkouts":
                self.getWorkouts(result: result)
            default:
                result(FlutterMethodNotImplemented)
            }
        }
    }
    
    private func requestAuthorization(result: @escaping FlutterResult) {
        let types = readTypes
        
        healthStore.requestAuthorization(toShare: nil, read: types) { success, error in
            DispatchQueue.main.async {
                if let error = error {
                    let errMsg = "[HealthKitService] Auth error: \(error.localizedDescription)"
                    print(errMsg)
                    result(FlutterError(code: "AUTH_ERROR", message: errMsg, details: nil))
                } else {
                    result(success)
                }
            }
        }
    }
    
    private func checkAuthorizationStatus(result: @escaping FlutterResult) {
        var statuses: [String: String] = [:]
        
        // **CRITICAL HEALTHKIT FACT**: You CANNOT check read authorization status in HealthKit for privacy reasons.
        // HKHealthStore.authorizationStatus() ONLY returns write (share) status.
        // It will always return .notDetermined or .sharingDenied if we only requested READ.
        // So for this frontend, we simply say "authorized" if we successfully returned from the Apple Prompt.
        for type in readTypes {
            let typeName = type.identifier.replacingOccurrences(of: "HKQuantityTypeIdentifier", with: "")
                .replacingOccurrences(of: "HKCategoryTypeIdentifier", with: "")
                .replacingOccurrences(of: "HKWorkoutTypeIdentifier", with: "Workout")
            
            // We just assume authorized since the prompt was shown, but the backend handles missing data gracefully.
            statuses[typeName] = "authorized"
        }
        
        result(statuses)
    }
    
    // MARK: - Queries
    
    private func getHeartRate(result: @escaping FlutterResult) {
        guard let heartRateType = HKObjectType.quantityType(forIdentifier: .heartRate) else { return result(nil) }
        
        let end = Date()
        let start = Calendar.current.date(byAdding: .hour, value: -24, to: end)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        
        var finalResult: [String: Any] = [:]
        let group = DispatchGroup()
        
        // 1. Latest
        group.enter()
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let sampleQuery = HKSampleQuery(sampleType: heartRateType, predicate: predicate, limit: 1, sortDescriptors: [sortDescriptor]) { _, samples, _ in
            if let sample = samples?.first as? HKQuantitySample {
                finalResult["current"] = sample.quantity.doubleValue(for: HKUnit(from: "count/min"))
            }
            group.leave()
        }
        healthStore.execute(sampleQuery)
        
        // 2. Average
        group.enter()
        let statisticsQuery = HKStatisticsQuery(quantityType: heartRateType, quantitySamplePredicate: predicate, options: .discreteAverage) { _, statistics, _ in
            if let avg = statistics?.averageQuantity() {
                finalResult["avg_24h"] = avg.doubleValue(for: HKUnit(from: "count/min"))
            }
            group.leave()
        }
        healthStore.execute(statisticsQuery)
        
        group.notify(queue: .main) {
            print("[HealthKitService] getHeartRate -> \(finalResult)")
            result(finalResult.isEmpty ? nil : finalResult)
        }
    }
    
    private func getHRV(result: @escaping FlutterResult) {
        guard let hrvType = HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN) else { return result(nil) }
        
        let end = Date()
        let start = Calendar.current.date(byAdding: .day, value: -7, to: end)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        
        var finalResult: [String: Any] = [:]
        let group = DispatchGroup()
        
        // 1. Latest
        group.enter()
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let sampleQuery = HKSampleQuery(sampleType: hrvType, predicate: predicate, limit: 1, sortDescriptors: [sortDescriptor]) { _, samples, _ in
            if let sample = samples?.first as? HKQuantitySample {
                finalResult["current"] = sample.quantity.doubleValue(for: HKUnit.secondUnit(with: .milli))
            }
            group.leave()
        }
        healthStore.execute(sampleQuery)
        
        // 2. Average
        group.enter()
        let statisticsQuery = HKStatisticsQuery(quantityType: hrvType, quantitySamplePredicate: predicate, options: .discreteAverage) { _, statistics, _ in
            if let avg = statistics?.averageQuantity() {
                finalResult["avg_7d"] = avg.doubleValue(for: HKUnit.secondUnit(with: .milli))
            }
            group.leave()
        }
        healthStore.execute(statisticsQuery)
        
        group.notify(queue: .main) {
            print("[HealthKitService] getHRV -> \(finalResult)")
            result(finalResult.isEmpty ? nil : finalResult)
        }
    }
    
    private func getSleep(result: @escaping FlutterResult) {
        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else { return result(nil) }
        
        let calendar = Calendar.current
        let now = Date()
        // Last night: 8 PM yesterday to 10 AM today
        // But more robustly, we just find all sleep sessions that ended between yesterday evening and now
        // A simple approach is from yesterday 12 PM to today 12 PM
        let start = calendar.date(byAdding: .hour, value: -24, to: now)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: now, options: .strictStartDate)
        
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(sampleType: sleepType, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: [sortDescriptor]) { _, samples, error in
            guard let samples = samples as? [HKCategorySample], error == nil else {
                DispatchQueue.main.async { result(nil) }
                return
            }
            
            var total: TimeInterval = 0
            var deep: TimeInterval = 0
            var rem: TimeInterval = 0
            var awake: TimeInterval = 0
            
            for sample in samples {
                let duration = sample.endDate.timeIntervalSince(sample.startDate)
                if #available(iOS 16.0, *) {
                    switch sample.value {
                    case HKCategoryValueSleepAnalysis.asleepDeep.rawValue: deep += duration
                    case HKCategoryValueSleepAnalysis.asleepREM.rawValue: rem += duration
                    case HKCategoryValueSleepAnalysis.awake.rawValue: awake += duration
                    case HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue,
                         HKCategoryValueSleepAnalysis.asleepCore.rawValue: total += duration
                    default: break
                    }
                } else {
                    // Pre-iOS 16 fallback
                    if sample.value == HKCategoryValueSleepAnalysis.asleep.rawValue {
                        total += duration
                    } else if sample.value == HKCategoryValueSleepAnalysis.awake.rawValue {
                        awake += duration
                    }
                }
            }
            // Add specified sleep to total
            total += deep + rem
            
            DispatchQueue.main.async {
                if total == 0 && deep == 0 && rem == 0 && awake == 0 {
                    print("[HealthKitService] getSleep -> nil")
                    result(nil)
                } else {
                    let dict: [String: Double] = [
                        "total_hours": total / 3600,
                        "deep_hours": deep / 3600,
                        "rem_hours": rem / 3600,
                        "awake_hours": awake / 3600
                    ]
                    print("[HealthKitService] getSleep -> \(dict)")
                    result(dict)
                }
            }
        }
        healthStore.execute(query)
    }
    
    private func getSteps(result: @escaping FlutterResult) {
        guard let stepType = HKObjectType.quantityType(forIdentifier: .stepCount) else { return result(nil) }
        
        let start = Calendar.current.startOfDay(for: Date())
        let end = Date()
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        
        let query = HKStatisticsQuery(quantityType: stepType, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, statistics, _ in
            DispatchQueue.main.async {
                if let sum = statistics?.sumQuantity() {
                    let steps = Int(sum.doubleValue(for: HKUnit.count()))
                    print("[HealthKitService] getSteps -> \(steps)")
                    result(steps)
                } else {
                    print("[HealthKitService] getSteps -> nil")
                    result(nil)
                }
            }
        }
        healthStore.execute(query)
    }
    
    private func getActiveEnergy(result: @escaping FlutterResult) {
        guard let energyType = HKObjectType.quantityType(forIdentifier: .activeEnergyBurned) else { return result(nil) }
        
        let start = Calendar.current.startOfDay(for: Date())
        let end = Date()
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        
        let query = HKStatisticsQuery(quantityType: energyType, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, statistics, _ in
            DispatchQueue.main.async {
                if let sum = statistics?.sumQuantity() {
                    let kcal = sum.doubleValue(for: HKUnit.kilocalorie())
                    print("[HealthKitService] getActiveEnergy -> \(kcal) kcal")
                    result(kcal)
                } else {
                    print("[HealthKitService] getActiveEnergy -> nil")
                    result(nil)
                }
            }
        }
        healthStore.execute(query)
    }
    
    private func getMindfulness(result: @escaping FlutterResult) {
        guard let type = HKObjectType.categoryType(forIdentifier: .mindfulSession) else { return result(nil) }
        
        let end = Date()
        let start = Calendar.current.date(byAdding: .day, value: -7, to: end)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: [sortDescriptor]) { _, samples, _ in
            guard let samples = samples as? [HKCategorySample], !samples.isEmpty else {
                DispatchQueue.main.async { result(nil) }
                return
            }
            
            let lastSession = samples.first!
            let lastDuration = lastSession.endDate.timeIntervalSince(lastSession.startDate) / 60
            
            let weeklyTotal = samples.reduce(0.0) { result, sample in
                result + sample.endDate.timeIntervalSince(sample.startDate)
            } / 60
            
            DispatchQueue.main.async {
                let dict: [String: Double] = [
                    "last_session_minutes": lastDuration,
                    "weekly_total_minutes": weeklyTotal
                ]
                print("[HealthKitService] getMindfulness -> \(dict)")
                result(dict)
            }
        }
        healthStore.execute(query)
    }
    
    private func getWorkouts(result: @escaping FlutterResult) {
        let type = HKObjectType.workoutType()
        
        let end = Date()
        let start = Calendar.current.date(byAdding: .day, value: -7, to: end)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictStartDate)
        
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: 1, sortDescriptors: [sortDescriptor]) { _, samples, _ in
            guard let workout = samples?.first as? HKWorkout else {
                DispatchQueue.main.async { result(nil) }
                return
            }
            
            var calories: Double? = nil
            if let energy = workout.totalEnergyBurned {
                calories = energy.doubleValue(for: HKUnit.kilocalorie())
            }
            
            let name = self.workoutName(for: workout.workoutActivityType)
            let duration = workout.duration / 60 // minutes
            
            DispatchQueue.main.async {
                let dict: [String: Any] = [
                    "type": name,
                    "duration_minutes": duration,
                    "calories": calories as Any
                ]
                print("[HealthKitService] getWorkouts -> \(dict)")
                result(dict)
            }
        }
        healthStore.execute(query)
    }
    
    private func workoutName(for type: HKWorkoutActivityType) -> String {
        switch type {
        case .running: return "Running"
        case .cycling: return "Cycling"
        case .walking: return "Walking"
        case .swimming: return "Swimming"
        case .traditionalStrengthTraining: return "Strength Training"
        case .yoga: return "Yoga"
        case .functionalStrengthTraining: return "Functional Training"
        case .highIntensityIntervalTraining: return "HIIT"
        default: return "Workout"
        }
    }
}
